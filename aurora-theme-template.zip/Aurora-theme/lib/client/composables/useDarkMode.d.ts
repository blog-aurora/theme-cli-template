import type { Ref } from 'vue';
export declare const useDarkMode: () => Ref<boolean>;
