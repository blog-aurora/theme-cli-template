import { ArchivePluginOptions } from './vuepress-plugin-archive';
export * from './vuepress-plugin-archive';
export default ArchivePluginOptions;
