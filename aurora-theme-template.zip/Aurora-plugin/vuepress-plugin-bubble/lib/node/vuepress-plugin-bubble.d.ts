import type { Plugin } from '@vuepress/core';
export declare type BubblePluginOptions = Record<never, never>;
export declare const BubblePluginOptions: Plugin<BubblePluginOptions>;
