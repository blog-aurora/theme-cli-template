import { BubblePluginOptions } from './vuepress-plugin-bubble';
export * from './vuepress-plugin-bubble';
export default BubblePluginOptions;
