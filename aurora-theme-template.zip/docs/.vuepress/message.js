module.exports = {
    //这里是将config.js中的公告部分单独提取出来，方便配置
    message: [
        '该博客主题为Aurora,<a href="https://github.com/qsyyke/vuepress-theme-aurora">vuepress-theme-Aurora</a>',
        "主题交流群: 681602026，欢迎各位大佬进群交流",
    ]
}