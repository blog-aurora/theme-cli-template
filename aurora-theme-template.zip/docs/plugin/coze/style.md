# Coze样式

## css变量

```css
:root {
    --coze-border-radius: 10px; /*圆角*/
    --coze-background: white;/*背景色*/
    --coze-margin-top: 1.5rem;/*margin-top值*/
    --coze-margin-bottom: 1.5rem;/*margin-bottom*/
    --coze-mood-content-background: rgba(255, 202, 212, 0.35);/*说说内容背景色*/
}
```

