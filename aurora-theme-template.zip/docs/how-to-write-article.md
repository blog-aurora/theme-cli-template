---
# date是手动设置此篇文章编写的时间
date: "2021/11/26 20:08"

# 手动设置此篇文章封面
coverUrl: "https://h2.ioliu.cn/bing/BrassBandTrumpet_ZH-CN8703910231_640x480.jpg?imageslim"

# 是否置顶
sticky: true

# 设置keyword 多个以,分开
keyword: 设置keyword,设置keyword,设置keyword,设置keyword

# 设置description
description: 这是此篇文章的描述

# 手动设置标题，否则使用h1标签作为标题
title: 这是一篇demo文章

# 这是设置标签，数组形式
tag: [Aurora,demo]

# 这里设置类别，数组形式
categories: [类别,demo类别]
---

这里开始写内容

